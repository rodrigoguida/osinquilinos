import * as React from 'react';
import { Text, View, StyleSheet, Button, Image, TextInput, Dimensions } from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';

const Stack = createStackNavigator();

import styles from './estilos/styles';

const Drawer = createDrawerNavigator();

import Login from './components/Login';
import MostrarPerfil from './components/MostrarPerfil';
import CadCondominio from './components/CadastrarCondominio';
import Morador from './components/CadastrarMorador';
import Editar from './components/Editar';

export default function App() {
  return (
    <NavigationContainer >
      <Stack.Navigator >
        <Stack.Screen name="Home" component={Login}/>
        <Stack.Screen name="Perfil" component={MostrarPerfil}/>
        <Stack.Screen name="Cadastro Condominio" component={CadCondominio}/>
        <Stack.Screen name="Cadastro Morador" component={Morador}/>
        <Stack.Screen name="Editar" component={Editar}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}


//initialRouteName = "Cadastro Condominio"
