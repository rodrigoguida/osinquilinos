import * as React from 'react';
import { Text, View, StyleSheet, Pressable, Image, TextInput, Dimensions,Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

import styles from '../estilos/styles';

export default function Editar({navigation}){
  return(
    <View style = {styles.container}>
      <View style = {styles.verde}>
        <Image source = {require ('../imagem/logo.png')} style = {styles.logo2}/>
        <View style = {{marginTop:150}}>
        <TextInput style={styles.entrada} placeholder="nome" />
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
        <TextInput style={styles.entradaMenor} placeholder="nascimento" />
        <TextInput style={styles.entradaMenorDireita} placeholder="cpf" />
        </View>
        <TextInput style={styles.entrada} placeholder="e-mail" />
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
        <TextInput style={styles.entradaMenor} placeholder="senha" secureTextEntry = {true}/>
        <TextInput style={styles.entradaMenorDireita} placeholder="senha" secureTextEntry = {true}/>
        </View>
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
        <TextInput style={styles.entradaMenor} placeholder="celular" />
        <TextInput style={styles.entradaMenorDireita} placeholder="telefone" />
        </View>
        </View>

        <Pressable onPress = {() => navigation.navigate('Cadastro Condominio')} style = {styles.botao2}>
          <Text style = {styles.textoBotao2}>próximo</Text>
        </Pressable>
      </View>
    </View>
  );
}



