import React, {useState} from 'react';
import {Text, View, StyleSheet, Pressable, Image, TextInput, Button} from 'react-native';

import Constants from 'expo-constants';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import styles from '../estilos/styles';

import Radio from './RadioButton'

export default function CadastroCondominio({navigation}){

  const [selected, setSelected] = useState(0);

  return(
  
    <View style = {styles.container}>
      <View style = {styles.verde}>
        <Image source = {require ('../imagem/logo.png')} style = {styles.logo}/>
        <View style = {{marginTop:220, padding:10}}>
          <TextInput style = {styles.entrada} placeholder="código do imóvel"/>
          <TextInput style = {styles.entrada} placeholder="código do condomínio"/> 
        
        
        <Radio 
          selected = {selected}
          options = {['proprietário','locatário']} 
          onChangeSelect = {(i) => setSelected(i)}
        />
     
        </View>    


        

        <Pressable onPress = {() => navigation.navigate('Perfil')} style = {styles.botao2}>
          <Text style = {styles.textoBotao2}>cadastrar</Text>
        </Pressable>
      </View>
    </View>
  );
}
