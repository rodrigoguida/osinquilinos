import * as React from 'react';
import { Text, View, StyleSheet, Pressable, Image, TextInput, TouchableOpacity,Button } from 'react-native';
import {RadioButton} from 'react-native-paper';

import styles from '../estilos/styles';

const Radio = ({selected, options=[], onChangeSelect }) =>{
  
  return(
    <View style={styles.fundo}>
      <Text style = {styles.textoMorador}>tipo de morador</Text>
    {
        options.map((opt, index) =>(
                 
          <TouchableOpacity onPress = {()=>onChangeSelect(index)} style = {styles.radio}>
            <View style = {styles.outlineCircle}>
              {selected == index && <View style = {styles.innerCircle} />}
            </View>

            <Text style = {styles.textoRadio}> {opt} </Text>

          </TouchableOpacity>
          
        //  <View style = {{flexDirection: 'row'}}>
        //   <RadioButton />
        //   <Text style= {styles.textoRadio}>{opt}</Text>
        // </View>
          
          
        ))
          
      }
    </View>
  );

}


// function Radio(props){
//   return(
//     <View style = {styles.fundo}>
//         <RadioButton/>
//         <Text style= {styles.textoRadio}>{props.options}</Text>
//     </View>
//   );
// }

export default Radio;

//  <Text style = {styles.textoMorador}>tipo de morador</Text>