import React from 'react';
import { Button, View, StyleSheet, Pressable, Text, Image, TextInput } from 'react-native';
import styles from '../estilos/styles';

export default function Login ({navigation}){
  return (
    
   <View style = {styles.container}>
      <View style = {styles.verde}>
        <Image source = {require ('../imagem/logo.png')} style = {styles.logo}/>
        <View style = {{marginTop:290, padding:10}}>
          <TextInput style = {styles.entrada} placeholder="cpf"/>
          <TextInput style = {styles.entrada} placeholder="senha" secureTextEntry = {true}/>
        </View>
        <Text style = {styles.textoSenha}>esqueci minha senha</Text>

        <Pressable onPress = {() => navigation.navigate('Perfil')} style = {styles.botao}>
          <Text style = {styles.textoBotao}>login</Text>
        </Pressable>
      </View>

        <Text style = {styles.cadastrese} onPress = {() => navigation.navigate('Cadastro Morador')}>cadastre-se </Text>
       
    </View>
  );
}