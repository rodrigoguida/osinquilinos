import * as React from 'react';
import { Text, View, StyleSheet, Pressable, Image, TextInput, Dimensions,Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

import styles from '../estilos/styles';

export default function Perfil({navigation}){
  return(
    <View style = {styles.container}>
      <View style = {styles.verde}>
        <Image source = {require ('../imagem/logo.png')} style = {styles.logo2}/>
        
        <View style = {{marginTop:150}}>
          <TextInput style={styles.entrada} value="Teste" />
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
          <TextInput style={styles.entradaMenor} value="01/01/2000" />
          <TextInput style={styles.entradaMenorDireita} value="123456789" />
        </View>
        <TextInput style={styles.entrada} value="teste@gmail.com" />
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
        <TextInput style={styles.entradaMenor} value="senha" secureTextEntry = {true}/>
        <TextInput style={styles.entradaMenorDireita} value="senha" secureTextEntry = {true}/>
        </View>
        <View style = {{flexDirection: 'row',alignSelf: 'center', marginBottom: 20}}>
        <TextInput style={styles.entradaMenor} value="(32)9999999" />
        <TextInput style={styles.entradaMenorDireita} value="(32)34412000" />
        </View>
        </View>

        <Pressable onPress = {() => navigation.navigate('Editar')} style = {styles.botao2}>
          <Text style = {styles.textoBotao2}>editar</Text>
        </Pressable>
      </View>
    </View>
  );
}



